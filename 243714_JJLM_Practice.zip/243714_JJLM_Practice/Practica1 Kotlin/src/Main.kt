//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    var day = readln()
    var isFriday: Boolean = false
    if (day.toInt() == 5){

        is Friday == true
    }
    println day
}
