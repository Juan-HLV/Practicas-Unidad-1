package formula

class Raices(val a: Int, val b: Int, val c: Int) {

    init {
        if (a == 0) {
            throw IllegalArgumentException("El coeficiente 'a' no puede ser cero")
        }
    }

    fun obtenerRaices(): Pair<Double, Double> {
        val discriminante = getDiscriminante()
        if (discriminante < 0) {
            throw IllegalArgumentException("No hay raíces reales")
        }
        val raiz1 = (-b + Math.sqrt(discriminante)) / (2.0 * a)
        val raiz2 = (-b - Math.sqrt(discriminante)) / (2.0 * a)
        return Pair(raiz1, raiz2)
    }

    fun obtenerRaiz(): Double {
        if (tieneRaiz()) {
            return -b.toDouble() / (2.0 * a)
        } else {
            throw IllegalArgumentException("No hay una única raíz real")
        }
    }

    fun getDiscriminante(): Double {
        return (b * b - 4 * a * c).toDouble()
    }

    fun tieneRaices(): Boolean {
        return getDiscriminante() > 0
    }

    fun tieneRaiz(): Boolean {
        return getDiscriminante() == 0.0
    }

    fun calcular() {
        if (tieneRaices()) {
            val (raiz1, raiz2) = obtenerRaices()
            println("Las raíces son: $raiz1 y $raiz2")
        } else if (tieneRaiz()) {
            val raiz = obtenerRaiz()
            println("La única raíz es: $raiz")
        } else {
            println("No hay raíces reales")
        }
    }
}