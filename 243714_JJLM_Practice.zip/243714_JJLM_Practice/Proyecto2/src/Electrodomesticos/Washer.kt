package models

class Washer(
    basePrice: Double,
    color: String,
    energyConsumption: Char,
    weight: Double,
    var capacity: Double,
    var spinSpeed: Int
) : Electronic(basePrice, color, energyConsumption, weight) {
    companion object {
        private const val DEFAULT_CAPACITY = 5.0
        private const val DEFAULT_SPIN_SPEED = 1000
    }

    constructor() : this(
        Electronic.DEFAULT_BASE_PRICE,
        Electronic.DEFAULT_COLOR,
        Electronic.DEFAULT_ENERGY_CONSUMPTION,
        Electronic.DEFAULT_WEIGHT,
        DEFAULT_CAPACITY,
        DEFAULT_SPIN_SPEED
    )

    constructor(price: Double, weight: Double) : this(
        price,
        Electronic.DEFAULT_COLOR,
        Electronic.DEFAULT_ENERGY_CONSUMPTION,
        weight,
        DEFAULT_CAPACITY,
        DEFAULT_SPIN_SPEED
    )

    override fun finalPrice(): Double {
        var price = super.finalPrice()
        if (capacity > 7) {
            price *= 1.20
        }
        if (spinSpeed > 1200) {
            price += 80.0
        }
        return price
    }
}