import models.Electronic
import models.TV
import models.Washer

fun main() {
    val electronics = arrayOfNulls<Electronic>(10)
    electronics[0] = Electronic(250.0, 15.0)
    electronics[1] = Washer(450.0, 65.0)
    electronics[2] = TV(100.0, 5.0)
    electronics[3] = Electronic(300.0, "rojo", 'B', 25.0)
    electronics[4] = TV(800.0, "negro", 'C', 18.0, 55, true)
    electronics[5] = Washer(400.0, "blanco", 'A', 55.0, 600.0, 1200)
    electronics[6] = Electronic()
    electronics[7] = TV()
    electronics[8] = Washer()
    electronics[9] = TV(1200.0, "gris", 'A', 25.0, 60, true)

    var totalElectronics = 0.0
    var washersSum = 0.0
    var tvSum = 0.0

    for (el in electronics) {
        val price = el?.finalPrice() ?: 0.0
        totalElectronics += price
        when (el) {
            is Washer -> washersSum += price
            is TV -> tvSum += price
        }
    }

    println("Suma total de electrodomésticos: ${"%.2f".format(totalElectronics)}")
    println("Suma total de lavadoras: ${"%.2f".format(washersSum)}")
    println("Suma total de televisiones: ${"%.2f".format(tvSum)}")
}