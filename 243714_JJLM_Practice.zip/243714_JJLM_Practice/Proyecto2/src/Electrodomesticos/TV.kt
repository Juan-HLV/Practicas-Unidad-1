package models

class TV(
    basePrice: Double,
    color: String,
    energyConsummation: Char,
    weight: Double,
    var resolution: Int,
    var tunerTDT: Boolean
) : Electronic(basePrice, color, energyConsummation, weight) {
    companion object {
        private const val DEFAULT_RESOLUTION = 20
        private const val DEFAULT_TUNER_TDT = false
    }

    constructor() : this(
        DEFAULT_BASE_PRICE,
        DEFAULT_COLOR,
        DEFAULT_ENERGY_CONSUME,
        DEFAULT_WEIGHT,
        DEFAULT_RESOLUTION,
        DEFAULT_TUNER_TDT
    )

    constructor(price: Double, weight: Double) : this(
        price,
        DEFAULT_COLOR,
        DEFAULT_ENERGY_CONSUME,
        weight,
        DEFAULT_RESOLUTION,
        DEFAULT_TUNER_TDT
    )

    override fun finalprice(): Double {
        var price = super.finalpricel()
        if (resolution > 40) {
            price *= 1.30
        }
        if (tunerTDT) {
            price += 50.0
        }
        return price
    }
}