package models

open class Electronic(
    var basePrice: Double,
    var color: String,
    var energyConsumption: Char,
    var weight: Double
) {
    companion object {
        const val DEFAULT_COLOR = "Blanco"
        const val DEFAULT_ENERGY_CONSUMPTION = 'F'
        const val DEFAULT_WEIGHT = 5.0
        const val DEFAULT_BASE_PRICE = 100.0
        val ALLOWED_COLORS = listOf("Blanco", "Negro", "Rojo", "Azul", "Gris")
        val ALLOWED_ENERGY_CONSUMPTIONS = listOf('A', 'B', 'C', 'D', 'E', 'F')
    }

    init {
        checkEnergyConsumption(energyConsumption)
        checkColor(color)
    }

    private fun checkEnergyConsumption(energyConsume: Char) {
        energyConsumption = if (ALLOWED_ENERGY_CONSUMPTIONS.contains(energyConsume)) energyConsume else DEFAULT_ENERGY_CONSUMPTION
    }

    private fun checkColor(color: String) {
        this.color = if (ALLOWED_COLORS.contains(color)) color else DEFAULT_COLOR
    }

    constructor(price: Double, weight: Double) : this(price, DEFAULT_COLOR, DEFAULT_ENERGY_CONSUMPTION, weight)
    constructor() : this(DEFAULT_BASE_PRICE, DEFAULT_COLOR, DEFAULT_ENERGY_CONSUMPTION, DEFAULT_WEIGHT)

    open fun finalPrice(): Double {
        var finalPrice = basePrice
        finalPrice += when (energyConsumption) {
            'A' -> 108.0
            'B' -> 80.0
            'C' -> 60.0
            'D' -> 50.0
            'E' -> 30.0
            'F' -> 10.0
            else -> 0.0
        }
        finalPrice += when (weight) {
            in 0.0..19.0 -> 10.0
            in 20.0..49.0 -> 50.0
            in 50.0..79.0 -> 80.0
            else -> 100.0
        }
        return finalPrice
    }
}