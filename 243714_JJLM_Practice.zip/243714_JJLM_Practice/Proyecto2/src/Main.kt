package formula

import formula.Raices

fun main() {
    println("Ingrese el valor de a:")
    var a: Int = readln().toInt()
    println("Ingrese el valor de b:")
    var b: Int = readln().toInt()
    println("Ingrese el valor de c:")
    var c: Int = readln().toInt()
    val ecuacion = Raices(a, b, c)
    ecuacion.calcular()
}