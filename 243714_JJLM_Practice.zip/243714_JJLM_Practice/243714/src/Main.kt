fun main() {
    print("Ingresa la cantidad en miligramos para la poción multijugos: ")
    val cantidad = readLine()?.toIntOrNull()

    if (cantidad == null) {
        println("Entrada inválida. Por favor, ingresa un número entero.")
    } else if (cantidad > 100) {
        println("¡Felicidades, es una buena poción multijugos!")
    } else {
        println("La poción es mediocre, sangre sucia inmunda.")
    }
}