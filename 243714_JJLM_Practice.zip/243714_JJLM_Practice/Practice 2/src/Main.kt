//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val personList: List<String> = listOf("Tony","Isaac", "Fernando")
    personList.forEach(::println)
    val personListMutable: ListMutable<String> = listOf("Tony","Isaac", "Fernando")
    personListMutable.add("Isaac")
    println(personlistMutable)
    personListMutable[1] = "Pedro"
    printlin(PearsonListMutable)
}